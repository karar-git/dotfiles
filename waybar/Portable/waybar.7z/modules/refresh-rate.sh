#!/bin/bash
# Portable Display Refresh Rate Toggle Script

# Configuration
CONFIG_FILE="$HOME/.config/hypr/monitors.conf"
HIGH_REFRESH_RATE="165"
LOW_REFRESH_RATE="60"

# Detect internal monitor (tries multiple patterns)
detect_internal_monitor() {
    local monitor_name=""
    
    # Try Hyprland
    if command -v hyprctl >/dev/null 2>&1; then
        # Try common internal display patterns
        local patterns=("eDP" "LVDS" "DSI" "HDMI-A-1" "DP-1")
        
        for pattern in "${patterns[@]}"; do
            monitor_name=$(hyprctl monitors 2>/dev/null | grep -E "Monitor.*$pattern" | awk '{print $2}' | head -1)
            if [[ -n "$monitor_name" ]]; then
                echo "$monitor_name"
                return
            fi
        done
        
        # Fallback: get first monitor
        monitor_name=$(hyprctl monitors 2>/dev/null | grep "Monitor" | awk '{print $2}' | head -1)
        if [[ -n "$monitor_name" ]]; then
            echo "$monitor_name"
            return
        fi
    fi
    
    # Try wlr-randr for sway/other wlroots compositors
    if command -v wlr-randr >/dev/null 2>&1; then
        local patterns=("eDP" "LVDS" "DSI")
        for pattern in "${patterns[@]}"; do
            monitor_name=$(wlr-randr 2>/dev/null | grep -E "^$pattern" | awk '{print $1}' | head -1)
            if [[ -n "$monitor_name" ]]; then
                echo "$monitor_name"
                return
            fi
        done
        
        # Fallback: get first connected display
        monitor_name=$(wlr-randr 2>/dev/null | grep -E "^[A-Z]" | awk '{print $1}' | head -1)
        if [[ -n "$monitor_name" ]]; then
            echo "$monitor_name"
            return
        fi
    fi
    
    # Try xrandr for X11
    if command -v xrandr >/dev/null 2>&1 && [[ -n "$DISPLAY" ]]; then
        local patterns=("eDP" "LVDS" "DSI")
        for pattern in "${patterns[@]}"; do
            monitor_name=$(xrandr 2>/dev/null | grep " connected" | grep -E "^$pattern" | awk '{print $1}' | head -1)
            if [[ -n "$monitor_name" ]]; then
                echo "$monitor_name"
                return
            fi
        done
        
        # Fallback: get first connected display
        monitor_name=$(xrandr 2>/dev/null | grep " connected" | awk '{print $1}' | head -1)
        if [[ -n "$monitor_name" ]]; then
            echo "$monitor_name"
            return
        fi
    fi
    
    echo ""
}

# Get current resolution for the monitor
get_monitor_resolution() {
    local monitor_name=$1
    
    # Try Hyprland
    if command -v hyprctl >/dev/null 2>&1; then
        local resolution=$(hyprctl monitors 2>/dev/null | grep -A 1 "Monitor $monitor_name" | grep -o '[0-9]*x[0-9]*' | head -1)
        if [[ -n "$resolution" ]]; then
            echo "$resolution"
            return
        fi
    fi
    
    # Try wlr-randr
    if command -v wlr-randr >/dev/null 2>&1; then
        local resolution=$(wlr-randr 2>/dev/null | grep -A 10 "^$monitor_name" | grep -E '[0-9]+x[0-9]+.*\*' | head -1 | grep -o '[0-9]\+x[0-9]\+')
        if [[ -n "$resolution" ]]; then
            echo "$resolution"
            return
        fi
    fi
    
    # Try xrandr
    if command -v xrandr >/dev/null 2>&1 && [[ -n "$DISPLAY" ]]; then
        local resolution=$(xrandr 2>/dev/null | grep -A 1 "^$monitor_name connected" | grep '\*' | head -1 | awk '{print $1}')
        if [[ -n "$resolution" ]]; then
            echo "$resolution"
            return
        fi
    fi
    
    echo "1920x1080" # Safe fallback
}

# Get current refresh rate
get_current_refresh_rate() {
    local monitor_name=$1
    
    # Try Hyprland
    if command -v hyprctl >/dev/null 2>&1; then
        local rate=$(hyprctl monitors 2>/dev/null | grep -A 1 "Monitor $monitor_name" | grep -o '@[0-9]*\.[0-9]*' | sed 's/@//' | head -1)
        if [[ -n "$rate" ]]; then
            echo "$rate"
            return
        fi
    fi
    
    # Try wlr-randr
    if command -v wlr-randr >/dev/null 2>&1; then
        local rate=$(wlr-randr 2>/dev/null | grep -A 10 "^$monitor_name" | grep -E '[0-9]+\.[0-9]+ Hz \*' | head -1 | grep -o '[0-9]\+\.[0-9]\+')
        if [[ -n "$rate" ]]; then
            echo "$rate"
            return
        fi
    fi
    
    # Try xrandr
    if command -v xrandr >/dev/null 2>&1 && [[ -n "$DISPLAY" ]]; then
        local rate=$(xrandr 2>/dev/null | grep -A 1 "^$monitor_name connected" | grep '\*' | head -1 | awk '{print $2}' | sed 's/\*//g')
        if [[ -n "$rate" ]]; then
            echo "$rate"
            return
        fi
    fi
    
    echo "60.00" # Safe fallback
}

# Set refresh rate based on display server
set_refresh_rate() {
    local monitor_name=$1
    local resolution=$2
    local target_rate=$3
    
    # Try Hyprland
    if command -v hyprctl >/dev/null 2>&1; then
        hyprctl keyword monitor "$monitor_name,${resolution}@${target_rate},0x0,1.0" >/dev/null 2>&1
        return $?
    fi
    
    # Try wlr-randr
    if command -v wlr-randr >/dev/null 2>&1; then
        wlr-randr --output "$monitor_name" --mode "${resolution}@${target_rate}Hz" >/dev/null 2>&1
        return $?
    fi
    
    # Try xrandr
    if command -v xrandr >/dev/null 2>&1 && [[ -n "$DISPLAY" ]]; then
        xrandr --output "$monitor_name" --mode "$resolution" --rate "$target_rate" >/dev/null 2>&1
        return $?
    fi
    
    return 1
}

# Update Hyprland config file (only if using Hyprland)
update_hypr_config() {
    local monitor_name=$1
    local resolution=$2
    local target_rate=$3
    
    if [[ -f "$CONFIG_FILE" ]] && command -v hyprctl >/dev/null 2>&1; then
        # Comment out current rate, uncomment target rate
        sed -i "s/^monitor=$monitor_name,${resolution}@${target_rate}/#monitor=$monitor_name,${resolution}@${target_rate}/" "$CONFIG_FILE"
        local other_rate=$([[ "$target_rate" == "$LOW_REFRESH_RATE" ]] && echo "$HIGH_REFRESH_RATE" || echo "$LOW_REFRESH_RATE")
        sed -i "s/^#monitor=$monitor_name,${resolution}@${other_rate}/monitor=$monitor_name,${resolution}@${other_rate}/" "$CONFIG_FILE"
    fi
}

# Main logic
MONITOR_NAME=$(detect_internal_monitor)

if [[ -z "$MONITOR_NAME" ]]; then
    echo "❌ No display found"
    exit 1
fi

RESOLUTION=$(get_monitor_resolution "$MONITOR_NAME")

case $1 in
    toggle)
        CURRENT_RATE=$(get_current_refresh_rate "$MONITOR_NAME")
        CURRENT_RATE_INT=$(printf "%.0f" "$CURRENT_RATE")
        
        if [[ "$CURRENT_RATE_INT" -ge 120 ]]; then
            if set_refresh_rate "$MONITOR_NAME" "$RESOLUTION" "$LOW_REFRESH_RATE"; then
                update_hypr_config "$MONITOR_NAME" "$RESOLUTION" "$HIGH_REFRESH_RATE"
                echo "🔄 Switched to ${LOW_REFRESH_RATE}Hz"
            else
                echo "❌ Failed to set ${LOW_REFRESH_RATE}Hz"
            fi
        else
            if set_refresh_rate "$MONITOR_NAME" "$RESOLUTION" "$HIGH_REFRESH_RATE"; then
                update_hypr_config "$MONITOR_NAME" "$RESOLUTION" "$LOW_REFRESH_RATE"
                echo "🔄 Switched to ${HIGH_REFRESH_RATE}Hz"
            else
                echo "❌ Failed to set ${HIGH_REFRESH_RATE}Hz"
            fi
        fi
        ;;
    status|*)
        CURRENT_RATE=$(get_current_refresh_rate "$MONITOR_NAME")
        CURRENT_RATE_INT=$(printf "%.0f" "$CURRENT_RATE")
        echo "🖥️  ${CURRENT_RATE_INT}Hz"
        ;;
esac
