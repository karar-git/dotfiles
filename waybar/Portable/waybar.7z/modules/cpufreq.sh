#!/bin/bash
# Portable CPU Governor + Refresh Rate Monitor

# Find available CPUs and get governor
get_cpu_governor() {
    # Try multiple CPU paths for portability
    local cpu_paths=(
        "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"
        "/sys/devices/system/cpu/cpufreq/policy0/scaling_governor"
    )
    
    for cpu_path in "${cpu_paths[@]}"; do
        if [[ -f "$cpu_path" ]]; then
            cat "$cpu_path" 2>/dev/null
            return
        fi
    done
    
    echo "unknown"
}

# Get current refresh rate (supports multiple display servers)
get_refresh_rate() {
    local refresh_display=""
    
    # Try Hyprland first
    if command -v hyprctl >/dev/null 2>&1; then
        local refresh_rate=$(hyprctl monitors 2>/dev/null | grep -E '@[0-9]+\.[0-9]+' | head -1 | sed -n 's/.*@\([0-9]\+\.[0-9]\+\).*/\1/p')
        if [[ -n "$refresh_rate" ]]; then
            refresh_rate=$(printf "%.0f" "$refresh_rate")
            echo " | 󰹑   ${refresh_rate}Hz"
            return
        fi
    fi
    
    # Try sway/wlr-randr
    if command -v wlr-randr >/dev/null 2>&1; then
        local refresh_rate=$(wlr-randr 2>/dev/null | grep -E '[0-9]+\.[0-9]+ Hz \*' | head -1 | grep -o '[0-9]\+\.[0-9]\+' | head -1)
        if [[ -n "$refresh_rate" ]]; then
            refresh_rate=$(printf "%.0f" "$refresh_rate")
            echo " | 󰹑   ${refresh_rate}Hz"
            return
        fi
    fi
    
    # Try X11 xrandr
    if command -v xrandr >/dev/null 2>&1 && [[ -n "$DISPLAY" ]]; then
        local refresh_rate=$(xrandr 2>/dev/null | grep '\*' | head -1 | awk '{print $2}' | sed 's/\*//g')
        if [[ -n "$refresh_rate" ]]; then
            refresh_rate=$(printf "%.0f" "$refresh_rate")
            echo " | 󰹑   ${refresh_rate}Hz"
            return
        fi
    fi
    
    echo ""
}

# Set CPU governor (tries multiple methods)
set_cpu_governor() {
    local target_governor=$1
    local success=false
    
    # Method 1: Try auto-cpufreq if available
    if command -v auto-cpufreq >/dev/null 2>&1; then
        if sudo -n auto-cpufreq --force "$target_governor" >/dev/null 2>&1; then
            success=true
        fi
    fi
    
    # Method 2: Try cpupower if auto-cpufreq failed
    if [[ "$success" == "false" ]] && command -v cpupower >/dev/null 2>&1; then
        if sudo -n cpupower frequency-set -g "$target_governor" >/dev/null 2>&1; then
            success=true
        fi
    fi
    
    # Method 3: Direct sysfs write as last resort
    if [[ "$success" == "false" ]]; then
        local cpu_paths=(
            "/sys/devices/system/cpu/cpu*/cpufreq/scaling_governor"
            "/sys/devices/system/cpu/cpufreq/policy*/scaling_governor"
        )
        
        for pattern in "${cpu_paths[@]}"; do
            for cpu_path in $pattern; do
                if [[ -f "$cpu_path" ]]; then
                    if echo "$target_governor" | sudo -n tee "$cpu_path" >/dev/null 2>&1; then
                        success=true
                    fi
                fi
            done
        done
    fi
    
    return $([[ "$success" == "true" ]] && echo 0 || echo 1)
}

# Handle click actions
case $1 in
    toggle)
        current_governor=$(get_cpu_governor)
        if [[ "$current_governor" == "powersave" ]]; then
            set_cpu_governor "performance"
        else
            set_cpu_governor "powersave"
        fi
        ;;
    reset)
        # Try auto-cpufreq reset first, fallback to setting ondemand/schedutil
        if command -v auto-cpufreq >/dev/null 2>&1; then
            sudo -n auto-cpufreq --force reset >/dev/null 2>&1
        else
            # Try common default governors
            set_cpu_governor "ondemand" || set_cpu_governor "schedutil" || set_cpu_governor "powersave"
        fi
        ;;
esac

# Get current state
current_governor=$(get_cpu_governor)
refresh_display=$(get_refresh_rate)

# Map governor to icon + text with refresh rate
case $current_governor in
    "performance")
        echo "󰾆   performance${refresh_display}"
        ;;
    "powersave")
        echo "󰂏 powersave${refresh_display}"
        ;;
    "ondemand")
        echo "⚖️ ondemand${refresh_display}"
        ;;
    "conservative")
        echo "🐌 conservative${refresh_display}"
        ;;
    "schedutil")
        echo "📊 schedutil${refresh_display}"
        ;;
    "userspace")
        echo "👤 userspace${refresh_display}"
        ;;
    *)
        echo "❓ $current_governor${refresh_display}"
        ;;
esac
